<?php
// 1. Inclusion du fichier de configuration
$db = require_once __DIR__.'/config/database.php';

// 2. Inclusion des classes nécessaires
require_once __DIR__.'/models/Article.php';
require_once __DIR__.'/models/Categorie.php';
require_once __DIR__.'/controllers/ArticleController.php';
require_once __DIR__.'/controllers/CategorieController.php';

if (!$db instanceof PDO) {
    die("Erreur : La connexion à la base de données a échoué.");
}else{
// 3. Initialisation des contrôleurs avec la connexion DB
try {
    $articleController = new ArticleController($db);
    $categorieController = new CategorieController($db);

    // 4. Router
    $request = $_SERVER['REQUEST_URI'];
    $basePath = '/mgls1_app'; 

    switch (parse_url($request, PHP_URL_PATH)) {
        case $basePath.'/':
            $articleController->index();
            break;
        case $basePath.'/ajouter':
            $articleController->ajouter();
            break;
        case $basePath.'/article':
            if (isset($_GET['id'])) {
                $articleController->show($_GET['id']);
            } else {
                $articleController->index();
            }
            break;
       case $basePath.'/article/add':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $articleController->store($_POST);
            } else {
                $articleController->ajouter(); 
            }
            break;
        case $basePath.'/article/edit':
            if (isset($_GET['id'])) {
                $articleController->edit($_GET['id']);
            }
            break;

        case $basePath.'/article/update':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $articleController->update($_POST['id'], $_POST);
            }
            break;

        case $basePath.'/article/delete':
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
                $articleController->delete($_POST['id']);
            }
            break;


        case $basePath.'/categories':
            $categorieController->index();
            break;
        case $basePath.'/categorie':
            if (isset($_GET['id'])) {
                $articleController->byCategory($_GET['id']);
            } else {
                $categorieController->index();
            }
            break;
        default:
            header('HTTP/1.0 404 Not Found');
            echo 'Page non trouvée';
            break;
    }
} catch (PDOException $e) {
    die("Erreur de base de données : " . $e->getMessage());
} catch (Exception $e) {
    die("Erreur : " . $e->getMessage());
}
}