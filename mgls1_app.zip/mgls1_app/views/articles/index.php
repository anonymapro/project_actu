<?php
$basePath = '/mgls1_app';
ob_start(); ?>

<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <!-- En-tête avec titre et éventuel filtre -->
    <div class="flex justify-between items-center mb-8 border-b border-gray-200 pb-6">
        <h1 class="text-3xl font-bold text-gray-900">
            <?php echo isset($categorie) ? "{$categorie->libelle}" : 'Tous nos articles'; ?>
        </h1>
        <?php if(isset($categorie)): ?>
            <a href="<?= $basePath ?>/articles" class="text-sm font-medium text-indigo-600 hover:text-indigo-500">
                Voir tous les articles →
            </a>
        <?php endif; ?>
    </div>

    <!-- Grille d'articles -->
    <div class="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-3 xl:gap-x-8">
        <?php foreach ($articles as $article): ?>
            <div class="group relative bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-all duration-300">
                <!-- Badge de catégorie -->
                <div class="absolute top-4 right-4 z-10">
                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                        <?php echo htmlspecialchars($article->categorie_libelle); ?>
                    </span>
                </div>
                
                <!-- Contenu de la carte -->
                <div class="p-6">
                    <!-- Date de publication -->
                    <div class="text-xs text-gray-500 mb-2">
                        <?php echo date('d M Y', strtotime($article->dateCreation)); ?>
                    </div>
                    
                    <!-- Titre -->
                    <h3 class="text-lg font-semibold text-gray-900 mb-3 group-hover:text-indigo-600 transition-colors">
                        <a href="<?= $basePath ?>/article?id=<?= $article->id ?>">
                            <span aria-hidden="true" class="absolute inset-0"></span>
                            <?php echo htmlspecialchars($article->titre); ?>
                        </a>
                    </h3>
                    
                    <!-- Extrait du contenu -->
                    <p class="text-gray-600 mb-4 line-clamp-3">
                        <?php echo htmlspecialchars($article->contenu); ?>
                    </p>
                    
                    <!-- Bouton Lire la suite -->
                    <div class="flex justify-between items-center mt-auto pt-4 border-t border-gray-100">
                        <a href="<?= $basePath ?>/article?id=<?= $article->id ?>" 
                           class="text-sm font-medium text-indigo-600 hover:text-indigo-500">
                            Lire l'article →
                        </a>
                        
                        <!-- Actions (modifier/supprimer) -->
                        <div class="flex space-x-4">
                            <a href="<?= $basePath ?>/article/edit?id=<?= $article->id ?>" 
                               class="text-gray-400 hover:text-indigo-500 transition-colors"
                               title="Modifier">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                    <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                                </svg>
                            </a>
                            
                            <form action="<?= $basePath ?>/article/delete" method="post" onsubmit="return confirm('Confirmer la suppression ?')">
                                <input type="hidden" name="id" value="<?= $article->id ?>">
                                <button type="submit" class="text-gray-400 hover:text-red-500 transition-colors" title="Supprimer">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" />
                                    </svg>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../../views/layout.php';
?>