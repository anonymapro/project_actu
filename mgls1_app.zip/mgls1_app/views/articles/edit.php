<?php
$basePath = '/mgls1_app';
ob_start(); ?>

<div class="max-w-3xl mx-auto">
    <!-- En-tête avec bouton de retour -->
    <div class="flex items-center justify-between mb-8">
        <h2 class="text-2xl font-bold text-gray-800">Modifier l'article</h2>
        <a href="<?= $basePath ?>/article?id=<?= $article->id ?>" class="text-sm font-medium text-gray-600 hover:text-primary flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Retour à l'article
        </a>
    </div>

    <!-- Formulaire -->
    <form action="<?= $basePath ?>/article/update" method="post" class="space-y-6 bg-white p-8 rounded-xl shadow-sm border border-gray-100">
        <input type="hidden" name="id" value="<?= $article->id ?>">

        <!-- Champ Titre -->
        <div class="space-y-2">
            <label for="titre" class="block text-sm font-medium text-gray-700">Titre de l'article *</label>
            <div class="mt-1 relative rounded-md shadow-sm">
                <input type="text" id="titre" name="titre" value="<?= htmlspecialchars($article->titre) ?>" required 
                       class="block w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary placeholder-gray-400 transition"
                       placeholder="Un titre accrocheur...">
            </div>
        </div>

        <!-- Champ Contenu -->
        <div class="space-y-2">
            <label for="contenu" class="block text-sm font-medium text-gray-700">Contenu *</label>
            <div class="mt-1">
                <textarea id="contenu" name="contenu" rows="8" required
                          class="block w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary placeholder-gray-400 transition"
                          placeholder="Écrivez votre contenu ici..."><?= htmlspecialchars($article->contenu) ?></textarea>
            </div>
            <p class="mt-1 text-sm text-gray-500">Utilisez le format Markdown pour une mise en forme avancée.</p>
        </div>

        <!-- Champ Catégorie -->
        <div class="space-y-2">
            <label for="categorie" class="block text-sm font-medium text-gray-700">Catégorie *</label>
            <div class="mt-1">
                <select id="categorie" name="categorie" required
                        class="block w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary transition appearance-none bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9ImN1cnJlbnRDb2xvciIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiPjxwb2x5bGluZSBwb2ludHM9IjYgOSAxMiAxNSAxOCA5Ij48L3BvbHlsaW5lPjwvc3ZnPg==')] bg-no-repeat bg-[right_1rem_center] bg-[length:1.5em]">
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= $cat['id'] == $article->categorie_id ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['libelle']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <!-- Actions -->
        <div class="pt-4 border-t border-gray-100 flex flex-col md:flex-row justify-between gap-4">
            <a href="<?= $basePath ?>/article/delete?id=<?= $article->id ?>" 
               class="px-6 py-3 text-red-600 hover:text-white hover:bg-red-600 font-medium rounded-lg border border-red-600 transition flex items-center justify-center text-center"
               onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet article ?')">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
                Supprimer l'article
            </a>
            
            <div class="flex gap-4">
                <a href="<?= $basePath ?>/article?id=<?= $article->id ?>" 
                   class="px-6 py-3 text-gray-600 hover:text-white hover:bg-gray-600 font-medium rounded-lg border border-gray-300 transition flex items-center justify-center">
                    Annuler
                </a>
                
                <button type="submit" 
                        class="px-6 py-3 bg-primary text-white font-medium rounded-lg hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Enregistrer
                </button>
            </div>
        </div>
    </form>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../../views/layout.php';
?>