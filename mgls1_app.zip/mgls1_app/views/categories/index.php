<?php ob_start(); ?>

    <h2>Catégories</h2>

    <ul>
        <?php foreach ($categories as $categorie): ?>
            <li>
                <a href="/categorie/<?php echo $categorie->id; ?>">
                    <?php echo htmlspecialchars($categorie->libelle); ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>

<?php
$content = ob_get_clean();
require 'layout.php';
?>