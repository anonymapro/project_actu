<?php
class Article {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getAll() {
        $query = $this->db->query('
            SELECT a.*, c.libelle as categorie_libelle 
            FROM Article a 
            JOIN Categorie c ON a.categorie = c.id
            ORDER BY a.dateCreation DESC
        ');
        return $query->fetchAll(PDO::FETCH_OBJ);
    }

    public function getByCategorie($categorieId) {
        $query = $this->db->prepare('
            SELECT a.*, c.libelle as categorie_libelle 
            FROM Article a 
            JOIN Categorie c ON a.categorie = c.id
            WHERE a.categorie = ?
            ORDER BY a.dateCreation DESC
        ');
        $query->execute([$categorieId]);
        return $query->fetchAll(PDO::FETCH_OBJ);
    }

    public function getById($id) {
        $query = $this->db->prepare('
            SELECT a.*, c.libelle as categorie_libelle 
            FROM Article a 
            JOIN Categorie c ON a.categorie = c.id
            WHERE a.id = ?
        ');
        $query->execute([$id]);
        return $query->fetch(PDO::FETCH_OBJ);
    }

    public function create($titre, $contenu, $categorie) {
        $query = $this->db->prepare('
            INSERT INTO Article (titre, contenu, categorie)
            VALUES (?, ?, ?)
        ');
        return $query->execute([$titre, $contenu, $categorie]);
    }

  
public function update($id, $titre, $contenu, $categorieId) {
    $stmt = $this->db->prepare("UPDATE article SET titre = ?, contenu = ?, categorie = ? WHERE id = ?");
    return $stmt->execute([$titre, $contenu, $categorieId, $id]);
}

    public function delete($id) {
        $query = $this->db->prepare('DELETE FROM Article WHERE id = ?');
        return $query->execute([$id]);
    }
}
?>