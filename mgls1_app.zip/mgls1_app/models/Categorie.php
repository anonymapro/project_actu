<?php
class Categorie {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getAll() {
        $query = $this->db->query('SELECT * FROM Categorie');
        return $query->fetchAll(PDO::FETCH_ASSOC);

    }

    public function getById($id) {
        $query = $this->db->prepare('SELECT * FROM Categorie WHERE id = ?');
        $query->execute([$id]);
        return $query->fetch(PDO::FETCH_OBJ);
    }
}
?>