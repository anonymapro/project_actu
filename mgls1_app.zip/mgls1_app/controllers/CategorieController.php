<?php
require_once __DIR__ . '/../models/Categorie.php';

class CategorieController {
    private $model;

    public function __construct($db) {
        $this->model = new Categorie($db);
    }

    public function index() {
        $categories = $this->model->getAll();
        require '../views/categories/index.php';
    }
}
?>