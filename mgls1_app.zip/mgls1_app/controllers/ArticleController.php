<?php
require_once __DIR__ . '/../models/Article.php';
require_once __DIR__ . '/../models/Categorie.php';
require_once __DIR__ . '/../config/database.php';

class ArticleController {
    private $articleModel;
    private $categorieModel;

    public function __construct($db) {
        $this->articleModel = new Article($db);
        $this->categorieModel = new Categorie($db);
    }

    public function index() {
        $articles = $this->articleModel->getAll();
        require __DIR__ . '/../views/articles/index.php'; 

    }

    public function show($id) {
        $article = $this->articleModel->getById($id);
        if ($article) {
            require __DIR__ . '/../views/articles/show.php';
        } else {
            header('HTTP/1.0 404 Not Found');
            echo 'Article non trouvé';
        }
    }
    

    public function byCategory($categorieId) {
        $articles = $this->articleModel->getByCategorie($categorieId);
        $categorie = $this->categorieModel->getById($categorieId);
        require '../views/articles/index.php';
    }

public function ajouter() {
    $categories = $this->categorieModel->getAll(); 
    require __DIR__ . '/../views/articles/ajouterArticle.php'; 
}


    public function store(array $data)
{
    $titre = trim($data['titre'] ?? '');
    $contenu = trim($data['contenu'] ?? '');
    $categorieId = (int)($data['categorie'] ?? 0);

    if (!$titre || !$contenu || !$categorieId) {
        echo "Champs manquants.";
        return;
    }

    $this->articleModel->create($titre, $contenu, $categorieId);
    header("Location: /mgls1_app/");
    exit;
}

public function edit($id) {
    $article = $this->articleModel->getById($id);
    $categories = $this->categorieModel->getAll();

    if ($article) {
        require __DIR__ . '/../views/articles/edit.php';
    } else {
        echo "Article non trouvé";
    }
}

public function update($id, array $data) {
    $titre = trim($data['titre'] ?? '');
    $contenu = trim($data['contenu'] ?? '');
    $categorieId = (int)($data['categorie'] ?? 0);

    if (!$titre || !$contenu || !$categorieId) {
        echo "Champs invalides.";
        return;
    }

    $this->articleModel->update($id, $titre, $contenu, $categorieId);
    header("Location: /mgls1_app/");
    exit;
}
public function delete($id) {
    $this->articleModel->delete($id);
    header("Location: /mgls1_app/");
    exit;
}

}
?>